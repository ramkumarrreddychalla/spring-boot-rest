package com.quardratic.equation.solver.service.exception;

public class EquationSyntaxException extends RuntimeException {

    public EquationSyntaxException(final String message) {
        super(message);
    }
}
